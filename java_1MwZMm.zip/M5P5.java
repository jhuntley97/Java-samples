// Jwaun Huntley
// 5/14/19

//Module 5 Problem 5

// Problem 5 -Create and print an example of each the following Java comparison operators: ==, !=, >, <, >=, and <=.


public class M5P5
{
  public static void main(String[]args)
  {
    int x = 10;
    int y = 5;
    
    System.out.println(x == y);
    	System.out.println(x != y);
    	System.out.println(x > y);
 		System.out.println(x < y);  
   		System.out.println(x >= y);
    	System.out.println(x <= y);
  }
}

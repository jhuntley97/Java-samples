// Jwaun Huntley
// 5/14/19

// Module 5 Problem 8

// Problem 8 - Use the Java Math class to print a random value.

import java.math.*;

public class M5P5
{
  public static void main(String []args)
  {
    
    System.out.println(Math.random());
    
  }
}